if (grassStarted()) {

# Citation
grassInfo()

# Version number
grassInfo("version")

# Version number
grassInfo("versionNumber")

# Version number
grassInfo("versionNumber")

# Copyright
grassInfo("copyright")

}
