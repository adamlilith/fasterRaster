#' Create BIOCLIM rasters
#'
#' @description The BIOCLIM set of variables were created for modeling species' geographic distributions (Booth et al. 2014). The "standard" set includes 19 variables, which can be created with this function:
#' * BIO01: Mean annual temperature, calculated using monthly means
#' * BIO02: Mean diurnal range across months (average of monthly difference between maximum and minimum temperature)
#' * BIO03: Isothermality (100 * BIO02 / BIO07)
#' * BIO04 Temperature seasonality (standard deviation across months of average monthly temperature * 100)
#' * BIO05: Maximum temperature of the warmest month (based on maximum temperature)
#' * BIO06: Minimum temperature of the coldest month (based on minimum temperature)
#' * BIO07: Range of annual temperature (BIO05 - BIO06)
#' * BIO08: Mean temperature of the wettest quarter (based on mean temperature)
#' * BIO09: Mean temperature of the driest quarter (based on mean temperature)
#' * BIO10: Mean temperature of the warmest quarter (based on mean temperature)
#' * BIO11: Mean temperature of the coldest quarter (based on mean temperature)
#' * BIO12: Total annual precipitation
#' * BIO13: Precipitation of the wettest month
#' * BIO14: Precipitation of the driest month
#' * BIO15: Precipitation seasonality (100 * coefficient of variation)
#' * BIO16: Precipitation of the wettest quarter
#' * BIO17: Precipitation of the driest quarter
#' * BIO18: Precipitation of the warmest quarter (based on mean temperature)
#' * BIO19: Precipitation of the coldest quarter (based on mean temperature)
#' * BIO41: Mean temperature of the quarter following the coldest quarter (based on mean temperature)
#' * BIO42: Mean temperature of the quarter following the warmest quarter (based on mean temperature)
#' * BIO43: Precipitation of the quarter following the coldest quarter (based on mean temperature)
#' * BIO44: Precipitation of the quarter following the warmest quarter (based on mean temperature)
#' * BIO45: Temperature of the quarter following the driest quarter (based on mean temperature)
#' * BIO46: Temperature of the quarter following the wettest quarter (based on mean temperature)
#' * BIO47: Precipitation of the quarter following the driest quarter (based on mean temperature)
#' * BIO48: Precipitation of the quarter following the wettest quarter (based on mean temperature)
#' * BIO49: Quarter with the highest temperature.
#' * BIO50: Quarter with the lowest temperature.
#' * BIO51: Quarter with the highest precipitation.
#' * BIO52: Quarter with the lowest precipitation.
#' 
#' "Quarter" refers to any consecutive run of three months, not a financial quarter. A quarter can thus include November-December-January, or December-January-February, for example.
#'
#' The variables are defined assuming that the input rasters represent monthly values (12 rasters for min/max temperature and precipitation), but you can also use sets of 52 rasters, representing one per week, in which case "quarter" would be a successive run of 3 weeks. You could also attempt 365 rasters, in which case a "quarter" would be a run of 3 successive days.
#'
#' BIOCLIMs 41 through 44 are added here to capture the "shoulder" seasons (spring and autumn) important in temperature regions. BIOCLIMs 45 through 48 are also included for consistency.
#'
#' BIOCLIMs 49 through 52 are not bioclimatic variables per se, but useful for assessing the properties of the variables that are defined based on the "-est" quarter.
#'
#' The numbering of the new BIOCLIMs was begun at 41 because BIOCLIMs 20 through 40 are taken (Kriticos et al. 2014).
#'
#' @param ppt A "stack" of `GRaster`s, representing monthly/weekly/daily precipitation.
#'
#' @param tmin,tmax A "stack" of `GRaster`s, representing monthly/weekly/daily minimum and maximum temperature.
#'
#' @param tmean Either `NULL` (default), or a "stack" of `GRaster`s, representing monthly/weekly/daily average temperature. If `NULL`, `tmean` will be calculated internally from `tmin` and `tmax`. Providing these rasters thus saves time if you already have them on hand.
#'
#' @param bios Either `NULL` (default), `"*"`, or a vector of numbers indicating which BIOLCIMs to calculate:
#' * `NULL`: Calculate BIOCLIMs 1 through 19
#' * `"*"`: Calculate all BIOCLIMs this function can calculate.
#' * `"+"`: Calculate BIOCLIMs 41 onward.
#' * Numeric values: Calculate these BIOCLIM varoables. For example, `bios = c(1, 12)` calculates BIOCLIMs 1 and 12.
#'
#' @param sample Logical: If `TRUE` (default), BIO4 and 15 are calculated with the sample standard deviation. If `FALSE`, then the population standard deviation is used.
#'
#' @returns A `GRaster` with one or more layers.
#'
#' @references Booth, T.H., Nix, H.A., Busby, J.R., and Hutchinson, M.F.  2014.  BIOCLIM: The first species distribution modeling package, its early applications and relevance to most current MaxEnt studies.  *Diversity and Distributions* 20:1-9 \doi{10.1111/ddi.12144}.
#'
#' Kriticos, D.J., Jarošik, V., and Otam N.  2014.  Extending the suite of BIOCLIM variables: A proposed registry system and case study using principal components analysis.  *Methods in Ecology and Evolution* 5:956-960 \doi{10.1111/2041-210X.12244}.
#'
#' @aliases bioclims
#' @rdname bioclims
#' @exportMethod bioclims
methods::setMethod(
	f = "bioclims",
	signature = c(ppt = "GRaster"),
	function(ppt, tmin, tmax, tmean = NULL, bios = NULL, sample = TRUE) {
	
	if (is.null(bios)) {
		bios <- 1:19
	} else if (length(bios) == 1L) {
		if (bios == "*") {
			bios <- c(1:19, 41:52)
		} else if (bios == "+") {
			bios <- c(41:52)
		}
	} else {
		bios <- unique(bios)
	}

	valids <- c(1:19, 41:52)
	
	if (any(omnibus::notIn(bios, valids))) stop("Argument ", sQuote("bios"), " has at least one invalid value. Valid values include:\n  ", paste(valids, collapse = " "))

	compareGeom(ppt, tmin, lyrs = TRUE)
	compareGeom(ppt, tmax, lyrs = TRUE)
	if (!is.null(tmean)) compareGeom(ppt, tmean, lyrs = TRUE)
	
	nLayers <- nlyr(ppt)
	precision <- faster("rasterPrecision")

	.locationRestore(ppt)
	.region(ppt)

	ppt <- sources(ppt)
	tmin <- sources(tmin)
	tmax <- sources(tmax)
	if (!is.null(tmean)) tmean <- sources(tmean)

	### calculate tmean if needed
	if (is.null(tmean) & any(bios %in% c(1, 4, 8:11, 18:19, 41:46))) {

		tmean <- .makeSourceName("r_mapcalc", "raster", nLayers)
		for (i in seq_len(nLayers)) {

			ex <- paste0(tmean[i], " = (", precision, "(", tmin[i], ") + ", precision, "(", tmax[i], ")) / 2")

			rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		}

	}

	### quarter temperature rasters
	if (any(bios %in% c(10, 11, 18, 19, 41:44, 49:50))) {
		tQ <- .calcQuarter(tmean, fun = "mean")
	}

	### quarter precipitation rasters
	if (any(bios %in% c(8, 9, 16, 17, 15:48, 51:52))) {
		pptQ <- .calcQuarter(ppt, fun = "sum")
	}

	### MAIN
	########

	out <- NULL

	### BIOCLIM 51 (wettest quarter)
	if (any(bios %in% c(8, 16, 46, 48, 51))) {
		
		src <- .makeSourceName("r_mapcalc", "raster")
		bio51 <- .makeSourceName("r_mapcalc", "raster", name = "bio51")

		rgrass::execGRASS(
			cmd = "r.series",
			input = pptQ,
			output = src,
			method = "max_raster",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		ex <- paste0(bio51, " = ", src, " + 1")
		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		# get vector of all wettest quarters
		wettestQuarters <- .freq(bio51, dtype = "CELL", digits = NA, bins = NA)

		wettestQuarters <- wettestQuarters[["value"]]

		if (51 %in% bios) out <- c(out, bio51)

	}

	### BIOCLIM 52 (driest quarter)
	if (any(bios %in% c(9, 17, 45, 47, 52))) {

		src <- .makeSourceName("r_mapcalc", "raster")
		bio52 <- .makeSourceName("r_mapcalc", "raster", name = "bio52")
		
		rgrass::execGRASS(
			cmd = "r.series",
			input = pptQ,
			output = src,
			method = "min_raster",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		ex <- paste0(bio52, " = ", src, " + 1")
		
		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		# get vector of all driest quarters
		driestQuarters <- .freq(bio52, dtype = "CELL", digits = NA, bins = NA)

		driestQuarters <- driestQuarters[["value"]]

		if (52 %in% bios) out <- c(out, bio52)

	}

	### BIO49 (warmest quarter)
	if (any(bios %in% c(10, 18, 42, 44, 49))) {

		src <- .makeSourceName("r_mapcalc", "raster")
		bio49 <- .makeSourceName("r_mapcalc", "raster", name = "bio49")
		
		rgrass::execGRASS(
			cmd = "r.series",
			input = tQ,
			output = src,
			method = "max_raster",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		ex <- paste0(bio49, " = ", src, " + 1")

		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		# vector of warmest quarters
		warmestQuarters <- .freq(bio49, dtype = "CELL", digits = NA, bins = NA)

		warmestQuarters <- warmestQuarters[["value"]]

		if (49 %in% bios) out <- c(out, bio49)

	}

	### BIOCLIM 50 (coldest quarter)
	if (any(bios %in% c(11, 19, 41, 43, 50))) {

		src <- .makeSourceName("r_mapcalc", "raster")
		bio50 <- .makeSourceName("r_mapcalc", "raster", name = "bio50")
		
		rgrass::execGRASS(
			cmd = "r.series",
			input = tQ,
			output = src,
			method = "min_raster",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		ex <- paste0(bio50, " = ", src, " + 1")

		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		# get vector of all coldest quarters
		coldestQuarters <- .freq(bio50, dtype = "CELL", digits = NA, bins = NA)

		coldestQuarters <- coldestQuarters[["value"]]

		if (50 %in% bios) out <- c(out, bio50)

	}

	### BIOCLIM 1
	if (any(bios %in% 1)) {
		
		bio1 <- .makeSourceName("r_series", "raster", n = 1L, name = "bio1")
		rgrass::execGRASS(
			"r.series",
			input = paste(tmean, collapse = ","),
			output = bio1,
			method = "average",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		if (1 %in% bios) out <- c(out, bio1)
	
	}

	### BIOCLIM 2
	if (any(bios %in% c(2, 3))) {
		
		meanMaxSrc <- .makeSourceName("r_series", "raster", n = 1L)
		meanMinSrc <- .makeSourceName("r_series", "raster", n = 1L)
		bio2 <- .makeSourceName("r_series", "raster", n = 1L, name = "bio2")

		# mean of maximums
		rgrass::execGRASS(
			"r.series",
			input = paste(tmax, collapse = ","),
			output = meanMaxSrc,
			method = "average",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		# mean of minimums
		rgrass::execGRASS(
			"r.series",
			input = paste(tmin, collapse = ","),
			output = meanMinSrc,
			method = "average",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		# bio2
		ex <- paste0(bio2, " = ", meanMaxSrc, " - ", meanMinSrc)

		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		if (2 %in% bios) out <- c(out, bio2)
	
	}

	### BIOCLIM 5
	if (any(bios %in% c(3, 5, 7))) {
		
		bio5 <- .makeSourceName("r_series", "raster", n = 1L, name = "bio5")

		rgrass::execGRASS(
			"r.series",
			input = paste(tmax, collapse = ","),
			output = bio5,
			method = "maximum",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		if (5 %in% bios) out <- c(out, bio5)
	
	}

	### BIOCLIM 6
	if (any(bios %in% c(3, 6, 7))) {
		
		bio6 <- .makeSourceName("r_series", "raster", n = 1L, name = "bio6")

		rgrass::execGRASS(
			"r.series",
			input = paste(tmin, collapse = ","),
			output = bio6,
			method = "minimum",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		if (6 %in% bios) out <- c(out, bio6)
	
	}

	### BIOCLIM 7 (annual temp range)
	if (any(bios %in% c(3, 7))) {
		
		bio7 <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio7")

		bio5 <- out[names(out) == "bio5"]
		bio6 <- out[names(out) == "bio6"]
		
		ex <- paste0(bio7, " = ", bio5, " - ", bio6)
		
		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		if (7 %in% bios) out <- c(out, bio7)
	
	}

	### BIOCLIM 3 (100 * bio2 / bio7)
	if (any(bios %in% 3)) {
		
		bio3 <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio3")

		bio2 <- out[names(out) == "bio2"]
		bio7 <- out[names(out) == "bio7"]
		
		ex <- paste0(bio3, " = 100 * ", bio2, " / ", bio7)
		
		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		if (3 %in% bios) out <- c(out, bio3)
	
	}

	### BIOCLIM 4 (100 * sd of temp)
	if (any(bios %in% 4)) {
		
		bio4 <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio4")

		rgrass::execGRASS(
			"r.series",
			input = paste(tmean, collapse = ","),
			output = bio4,
			method = "stddev",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		# convert to sample SD as per R
		if (sample) {
		
			srcIn <- bio4
			bio4 <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio4")

			ex <- paste0(bio4, " = 100 * sqrt((", nLayers, " * (", srcIn, "^2)) / (", nLayers, " - 1))")
			
			rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))
		
		}

		if (4 %in% bios) out <- c(out, bio4)
	
	}

	# BIOCLIM 8 (mean temp of wettest quarter)
	if (any(bios %in% 8)) {
		
		# burn temperature of wettest quarter to cells
		bio8 <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio8")

		ex <- paste0(bio8, " = ")
		for (i in wettestQuarters) {
			ex <- paste0(ex, "if(", bio51, "==", i, ",", tQ[i], ",")
		}
		ex <- paste0(ex, "null()", paste(rep(")", length(wettestQuarters)), collapse = ""))

		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		if (8 %in% bios) out <- c(out, bio8)

	}

	# BIOCLIM 9 (mean temp of driest quarter)
	if (any(bios %in% 9)) {

		# burn temperature of driest quarter to cells
		bio9 <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio9")

		ex <- paste0(bio9, " = ")
		for (i in driestQuarters) {
			ex <- paste0(ex, "if(", bio52, "==", i, ",", tQ[i], ",")
		}
		ex <- paste0(ex, "null()", paste(rep(")", length(driestQuarters)), collapse = ""))

		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		if (9 %in% bios) out <- c(out, bio9)

	}

	# BIOCLIM 10 (mean temp of warmest quarter)
	if (any(bios %in% 10)) {

		# burn temperature of warmest quarter to cells
		bio10 <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio10")

		ex <- paste0(bio10, " = ")
		for (i in warmestQuarters) {
			ex <- paste0(ex, "if(", bio49, "==", i, ",", tQ[i], ",")
		}
		ex <- paste0(ex, "null()", paste(rep(")", length(warmestQuarters)), collapse = ""))

		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		if (10 %in% bios) out <- c(out, bio10)

	}

	# BIOCLIM 11 (mean temp of coldest quarter)
	if (any(bios %in% 11)) {

		# burn temperature of coldest quarter to cells
		bio11 <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio11")

		ex <- paste0(bio11, " = ")
		for (i in coldestQuarters) {
			ex <- paste0(ex, "if(", bio50, "==", i, ",", tQ[i], ",")
		}
		ex <- paste0(ex, "null()", paste(rep(")", length(coldestQuarters)), collapse = ""))

		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		if (11 %in% bios) out <- c(out, bio11)

	}

	# BIOCLIM 12 (total precipitation)
	if (any(bios %in% c(12, 15))) {

		bio12 <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio12")

		input <- paste0(ppt, collapse = ",")

		rgrass::execGRASS(
			cmd = "r.series",
			input = input,
			output = bio12,
			method = "sum",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		if (12 %in% bios) out <- c(out, bio12)

	}

	# BIOCLIM 13 (wettest month precipitation)
	if (any(bios %in% 13)) {

		bio13 <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio13")

		input <- paste0(ppt, collapse = ",")

		rgrass::execGRASS(
			cmd = "r.series",
			input = input,
			output = bio13,
			method = "maximum",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		if (13 %in% bios) out <- c(out, bio13)

	}

	# BIOCLIM 14 (driest month precipitation)
	if (any(bios %in% 14)) {

		bio14 <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio14")

		input <- paste0(ppt, collapse = ",")

		rgrass::execGRASS(
			cmd = "r.series",
			input = input,
			output = bio14,
			method = "minimum",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		if (14 %in% bios) out <- c(out, bio14)

	}

	### BIOCLIM 15 (CV of precipitation)
	if (any(bios %in% 15)) {
		
		sdSrc <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio15")

		rgrass::execGRASS(
			"r.series",
			input = paste(ppt, collapse = ","),
			output = sdSrc,
			method = "stddev",
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

		# convert to sample SD as per R
		if (sample) {
		
			srcIn <- sdSrc
			sdSrc <- .makeSourceName("r_mapcalc", "raster", n = 1L)

			ex <- paste0(sdSrc, " = sqrt((", nLayers, " * (", srcIn, "^2)) / (", nLayers, " - 1))")
			
			rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))
		
		}

		bio15 <- .makeSourceName("r_mapcalc", "raster", name = "bio15")
		
		ex <- paste0(bio15, " = 100 * ", sdSrc, " / ", bio12)
		
		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		if (15 %in% bios) out <- c(out, bio15)
	
	}

	# BIOCLIM 16 (precipitation of the wettest quarter)
	if (any(bios %in% 16)) {

		# burn precipitation of wettest quarter to cells
		bio16 <- .makeSourceName("r_mapcalc", "raster", n = 1L, name = "bio16")

		ex <- paste0(bio16, " = ")
		for (i in wettestQuarters) {

			ex <- paste0(ex, "if(", bio51, "==", i, ",", pptQ[i], ",")
	
		}
		ex <- paste0(ex, "null()", paste(rep(")", length(wettestQuarters)), collapse = ""))

		rgrass::execGRASS("r.mapcalc", expression = ex, flags = c(.quiet(), "overwrite"))

		if (16 %in% bios) out <- c(out, bio16)

	}

	outNames <- names(out)
	nc <- nchar(outNames)
	shorts <- out[nc == 4L]
	longs <- out[nc == 5L]

	shorts <- shorts[order(names(shorts))]
	longs <- longs[order(names(longs))]

	out <- c(shorts, longs)

	names <- names(out)
	.makeGRaster(out, name = names)

	} # EOF
)


#' Calculate a series of "quarter" rasters and return their [sources()] names. A quarter can be summarized using 
#'
#' x Character vector of raster [sources()] names (usually 12 or 52)
#' fun Character: Name of function to summarize across a quarter. Allowed values are "sum", "min", "max", or "mean".
#'
#' @noRd
.calcQuarter <- function(x, fun) {

	n <- length(x)
	srcs <- .makeSourceName("r_mapcalc", "raster", n = n)
	for (i in seq_len(n)) {

		if (i < n - 2L) {
			input <- x[i:(i + 2L)]
		} else if (i == n - 1L) {
			input <- x[c(i:n, 1L)]
		} else if (i == n) {
			input <- x[c(n, 1L:2L)]
		}

		method <- if (fun == "sum") {
			"sum"
		} else if (fun == "min") {
			"minimum"
		} else if (fun == "max") {
			"maximum"
		} else if (fun == "mean") {
			"average"
		}

		rgrass::execGRASS(
			"r.series",
			input = input,
			output = srcs[i],
			method = method,
			nprocs = faster("cores"),
			memory = faster("memory"),
			flags = c(.quiet(), "overwrite", "n")
		)

	} # next quarter

	srcs

}
