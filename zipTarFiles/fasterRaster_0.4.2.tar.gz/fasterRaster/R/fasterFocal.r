#' Multi-core version of the focal() function
#'
#' This function applies a function that uses values from a "moving window" across a raster. It is exactly the same as the \code{\link[raster]{focal}} function in the \pkg{raster} package except that it can use a multi-core implementation to speed processing.
#' @param rast Raster object.
#' @param w Matrix of weights (the moving window), e.g. a 3 by 3 matrix with values 1. The matrix does not need to be square, but the sides must be odd numbers. If you need even sides, you can add a column or row with weights of zero. Alternatively, \code{w} can be an odd integer > 0, in which case a weights matrix \code{w} by \code{w} in size is created with every value equal to 1.
#' @param fun Function. The function must accept multiple numbers and return a single number. For example \code{mean}, \code{min}, or \code{max}. The function should also accept a \code{na.rm} argument (or ignore it, e.g. as one of the 'dots' arguments). For example, \code{length} will fail, but \code{function(rast, ...) { na.omit(length(rast)) }} works. The default function is \code{sum}.
#' @param filename Character, name of file for a new raster (optional).
#' @param na.rm Logical, if code{FALSE} (default) the value computed by \code{fun} will be \code{NA} only if all cells in the window are \code{NA}. Using \code{na.rm = TRUE} is usually not a good idea since it can unbalance weights.
#' @param pad Logical, if \code{TRUE} then add virtual rows and columns around the raster so that there are no edge effects. The virtual rows and columns are set to equal \code{padValue}. Default is \code{FALSE}.
#' @param padValue Value to which to set the values of the virtual cells used to pad the raster if \code{pad} is \code{TRUE}.
#' @param progress Logical, if \code{TRUE} display a progress bar. Only works if using multi-core calculation.
#' @param NAonly Logical, if \code{TRUE} then only cells with a value of \code{NA} have values replaced. Default is \code{FALSE}.
#' @param cores Integer >0, number of CPU cores to use to calculate the focal function (default is 2).
#' @param forceMulti Logical, if \code{TRUE} (default) then the function will attempt to use the total number of cores in \code{cores}. (Note that this many not necessarily be faster since each core costs some overhead.)  If \code{FALSE}, then the function will use up to \code{cores} if needed (which also may not be faster... it always depends on the problem being computed).
#' @param ... Arguments to pass to \code{\link[raster]{writeRaster}}
#' @return A raster object, possibly also written to disk.
#' @seealso \code{\link[raster]{focal}}
#' @examples
#' \donttest{
#' }
#' @export
fasterFocal <- function(
	rast,
	w = 3,
	fun = sum,
	filename = '',
	na.rm = FALSE,
	pad = FALSE,
	padValue = NA,
	NAonly = FALSE,
	progress = FALSE,
	cores = 2,
	forceMulti = TRUE,
	...
) {

	# get number of cores and chunks of raster
	cores <- .getCores(rast = rast, cores = cores, forceMulti = forceMulti)
	blocks <- raster::blockSize(rast, minblocks=cores)
	
	# single core
	if (cores == 1 | blocks$n == 1) {
	
		out <- raster::focal(x=rast, w=w, fun=fun, filename=filename, na.rm=na.rm, pad=pad, padValue=padValue, NAonly=NAonly, ...)
		
	# multi-core
	} else {

		# weights matrix
		if (class(w) == 'matrix') {
		
			badWeights <- if (nrow(w) != ncol(w)) {
				TRUE
			} else if (nrow(w) %% 2 != 1 | ncol(w) %% 2 != 1) {
				TRUE
			} else {
				FALSE
			}
		
		} else if (class(w) != 'matrix' && length(w) == 1) {
		
			if (w %% 2 != 1) {
				badWeights <- FALSE
			} else {
				w <- matrix(1, ncol=w, nrow=w)
				badWeights <- FALSE
			}
		
		} else {
			badWeights <- TRUE
		}
		
		if (badWeights) stop('Argument "w" in fasterFocal() function must be a square matrix with an odd number of sides or an odd integer.')
	
		halfWindowSize <- (nrow(w) - 1) / 2

		# add padding around raster to avoid edge effects
		if (pad) {
			origExtent <- raster::extent(rast)
			rast <- raster::extend(rast, y=halfWindowSize, value=padValue)
		}
	
		out <- raster::raster(rast)

		# calculate start/end position and size of each block to be sent to a core
		# and start/end position and size of each section in a block that is processed
		# account for overlap between blocks because of using a window
		# rows sent to nodes are "send"
		# rows which receive values are "process"
		maxBlockSize <- blocks$nrows[1]
		startSendRows <- seq(1, nrow(rast), by=maxBlockSize - 2 * halfWindowSize)
		endSendRows <- startSendRows + maxBlockSize - 1
		if (any(endSendRows > nrow(rast))) endSendRows[endSendRows > nrow(rast)] <- nrow(rast)
		numSendRows <- endSendRows - startSendRows + 1
		if (any(numSendRows < nrow(w))) {
			tooSmalls <- which(numSendRows < nrow(w))
			startSendRows <- startSendRows[-tooSmalls]
			endSendRows <- endSendRows[-tooSmalls]
			numSendRows <- numSendRows[-tooSmalls]
		}
		
		startProcessRows <- startSendRows + halfWindowSize
		endProcessRows <- endSendRows - halfWindowSize
		numProcessRows <- endProcessRows - startProcessRows + 1
		
		### initiate cluster
		nodes <- blocks$n
		raster::beginCluster(nodes)
		cluster <- raster::getCluster()
		on.exit(raster::endCluster())

		### start nodes calculating
		xCols <- ncol(rast)

		# data frame to track what's been sent to what "tag" node
		tracker <- data.frame(
			job = seq_along(startSendRows),
			tag = NA,
			sent = FALSE,
			done = FALSE,
			startSendRow = startSendRows,
			endSendRow = endSendRows,
			numSendRow = numSendRows,
			startProcessRow = startProcessRows,
			endProcessRow = endProcessRows,
			numProcessRow = numProcessRows
		)
		
		if (progress) pb <- pbCreate(nrow(tracker))

		for (tag in 1:nodes) {

			blockVals <- getValues(rast, startSendRows[tag], numSendRows[tag])
			blockVals <- matrix(blockVals, ncol=xCols, byrow=TRUE)
			
			snow::sendCall(cluster[[tag]], fun=.workerFocal, args=list(blockVals=blockVals, w=w, fun=fun, na.rm=na.rm, NAonly=NAonly), tag=tag)
			
			tracker$tag[tag] <- tag
			tracker$sent[tag] <- TRUE
		
		}
		
		# initiate file names if needed
		filename <- raster::trim(filename)
		if (!raster::canProcessInMemory(out) & filename == '') {
			filename <- raster::rasterTmpFile()
			out <- raster::writeStart(out, filename=filename, ... )
		}

		if (filename != '') {
			out <- raster::writeStart(out, filename=filename, ... )
		} else {
			out <- matrix(nrow=nrow(rast), ncol=ncol(rast))
		}
		
		### get and remember output
		while (sum(tracker$done) < nrow(tracker)) {

			thisTag <- tracker$tag[which(!tracker$done)[1]]
		
			# receive results from a node
			outFromClust <- snow::recvData(cluster[[thisTag]])
			if (!outFromClust$success) stop('Cluster error.')

			job <- which(outFromClust$tag == tracker$tag & tracker$sent & !tracker$done)
			tag <- outFromClust$tag
			tracker$done[job] <- TRUE
			
			# trim output to processed region
			valsFromClust <- outFromClust$value
			valsFromClust <- valsFromClust[(halfWindowSize + 1):(nrow(valsFromClust) - halfWindowSize), ]
			
			# get block
			if (filename != '') {
				valsFromClust <- c(t(valsFromClust))
				out <- raster::writeValues(out, v=valsFromClust, start=startProcessRows[job])
			} else {
				out[startProcessRows[job]:endProcessRows[job], 1:ncol(rast)] <- valsFromClust
			}

			# need to send more data?
			if (sum(tracker$sent) < nrow(tracker)) {

				job <- which(!tracker$sent & !tracker$done)[1]
				blockVals <- getValues(rast, startSendRows[job], numSendRows[job])
				blockVals <- matrix(blockVals, ncol=xCols, byrow=TRUE)
				
				snow::sendCall(cluster[[tag]], fun=.workerFocal, args=list(blockVals=blockVals, w=w, fun=fun, na.rm=na.rm, NAonly=NAonly), tag=tag)
				
				tracker$tag[job] <- tag
				tracker$sent[job] <- TRUE
			
			}
			
			if (progress) pbStep(pb)
			
		} # while not all chunks have been returned

		if (filename != '') {
			
			# write NAs to border rows at top and bottom
			fills <- rep(NA, ncol(rast) * halfWindowSize)
			raster::writeValues(out, v=fills, start=1)
			raster::writeValues(out, v=fills, start=nrow(rast) - halfWindowSize + 1)

			out <- writeStop(out)

		} else {
		
			out <- raster(out)
			raster::projection(out) <- raster::projection(rast)
			raster::extent(out) <- raster::extent(rast)
		
		}
		
		if (progress) pbClose(pb)
		
	} # if multi-core

	if (pad) out <- raster::crop(out, origExtent)
	out

}
