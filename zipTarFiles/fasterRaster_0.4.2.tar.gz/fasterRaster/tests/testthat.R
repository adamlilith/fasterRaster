library(testthat)
library(fasterRaster)

test_check("fasterRaster")
