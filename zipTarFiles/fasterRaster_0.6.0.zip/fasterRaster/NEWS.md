fasterRaster 0.6.0 (2020-09-04)
Add generic function faster() to call most GRASS modules easily
Add fasterContour(): Contours from rasters
Add fasterConvertDegree(): Convert degrees
Add fasterMapcalc(): Raster calculation
Add fasterSun(): Solar irradiation and radiation
Add fasterSurfFractal(): Fractal raster
Add fasterTopoidx(): Topographic wetness index
Publicize initGrass(): Now you can use it, too!
User can provide names of objects created by GRASS in most functions
Update PROJ4 strings in data objects
Update help a lot

fasterRaster 0.5.1 (2020-09-02)
Add fasterContour()

fasterRaster 0.5.0 (2020-09-01)
Updated for GRASS 7.8.

fasterRaster 0.4.x (before 2020-09)
Worked for Open Source Geospatial (OSGeo) GRASS 7.4
